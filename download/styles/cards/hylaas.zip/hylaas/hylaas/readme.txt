hylaas card style

Sources:
courier and bitstream fonts (both freely usable for hit type of thing as far as I know)
card images from the gpl 2'd pokerth 4-colored card set (see pokerth.net)
and some images adapted from http://ftp.debian.org/debian/pool/main/p/pysol-cardsets/pysol-cardsets_4.40.orig.tar.gz
specifically from cardset-xskat-french-large which is licensed like this

This PySol cardset was adapted from the game XSkat 3.2
http://www.gulu.net/xskat/

Copyright (C) 1999 Gunter Gerhardt <gerhardt@draeger.com>
Copyright (C) 2000 T. Kirk <grania@mailcity.com>

This cardset is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2 of
the License, or (at your option) any later version.

--------

This cardset is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2 of the License.


Copyright (C) 2009 Jan Hein Dykstra <janheyn@gmail.com>
