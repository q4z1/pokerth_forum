
Hello.

Here are the third parties material I used to make this PokerTH Table Style :


1. The Floor texture was found here (and then modified) : 
http://www.cgtextures.com
http://www.cgtextures.com/texview.php?id=22592&PHPSESSID=b215b05e37973236cf9888579d1ade71

Since the texture from this website was not tiled, I just used a part of it and I modified it to suit my needs.
I don't join the sources files anymore in the RAR file. If you want to know how I did the table style, download or my table style #01 or #02.


2. And for chairs, I used a free 3D model from there :
http://www.coolsc.net
http://www.coolsc.net/3D-Details/2006/11/27/1615-0.htm
...


3. I didn't use any texture for the carpet.



Thanks for using my PokerTH table style !



-----------------------------------------------------
Contact :
nick :  xanax (on forums and irc)
name :  Sebastien Kerguen (in real life)
email : sebastienkerguen@free.fr 



