Night Bright					Version 1.02
PokerTH Table Style
By Divisor
-------------------------------------------------------------
1.00						(14.12.2017)

- Initial release
-------------------------------------------------------------
1.01						(22.12.2017)

- Corrected pot text/border overlapping.
- Added flop/turn/river card holder gfx.
- Added more card-back gfx.
-------------------------------------------------------------
1.02						(12.01.2018)

- Rainbow background added for table view.
- Corrected border spacing of card area.
- Universal brightness/vibrancy increase.
- More distinctive active player seat.
- Re-styled custom action descriptors.
- Lower saturated, disabled radio buttons.
- More outstanding dealer/blind indicators.
- Shrunken checked player action buttons.
- Toolbox speed compartment.
- Table font color adjustments.
- Card-back color adjustments.
- More thematic default avatar.
- Extra XML/Table PNG for full screen option.
-------------------------------------------------------------
Resources

- Nonstop Regular - Version 2 (TrueType).