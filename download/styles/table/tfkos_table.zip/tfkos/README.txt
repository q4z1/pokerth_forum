Table style for PokerTH 1.1.2

1024x600 resolution only.

ALL CREDITS GO FOR ALL THE CREATORS.

Made with a mixture of all table elements available here = https://pokerth.net/app.php/gallery

Installation path (unzip) :

....PokerTH-1.1.2\data\gfx\gui\table

Add in to PokerTH :

Settings, Configure PokerTH, Style, Add, navigate to the Style folder find the tfkos.xml file.

Add flipside:

Settings, Configure PokerTH, Style, Use custom cardback picture navigate to the Style folder find the flipside.png file.













